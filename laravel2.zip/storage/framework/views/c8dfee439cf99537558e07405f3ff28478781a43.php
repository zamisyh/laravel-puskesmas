<div class="card-body">
    <form
        <?php if($pendaftaranId): ?>
            wire:submit.prevent='updatePendaftaran(<?php echo e($pendaftaranId); ?>)'
        <?php else: ?>
            wire:submit.prevent='savePendaftaran'
        <?php endif; ?>
    >
       
        <div class="row">
            <div class="col-lg-5">
                <h5>Data Pendaftaran</h5>

                <div class="form-group">
                    <label for="no_rawat">No Rawat</label>
                    <input wire:model.lazy='no_rawat' type="text" class="form-control" readonly>
                </div>

                <div class="form-group">
                    <label for="dokter">Dokter Penanggung Jawab</label>
                    <select wire:model.lazy='dokter' class="form-control <?php $__errorArgs = ['dokter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="dokter">
                        <option selected>Pilih</option>
                         <?php $__currentLoopData = $data_dokter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama_dokter); ?></option>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['dokter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label for="poli">Poli Tujuan</label>
                    <select wire:model.lazy='poli' class="form-control <?php $__errorArgs = ['poli'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="poli">
                        <option selected>Pilih</option>
                         <?php $__currentLoopData = $data_poli; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama_poli); ?></option>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['poli'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div> 
            <div class="col-lg-7">
                <h5>Data Pasien</h5>
                
        
                <div class="form-group" wire:ignore>
                    <label for="pasien">Pasien</label>
                    <select  id="pasien" wire:model.lazy='pasien' class="form-control <?php $__errorArgs = ['pasien'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <option selected>Pilih</option>
                         <?php $__currentLoopData = $data_pasien; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama_pasien); ?></option>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['pasien'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label for="no_rekamedis">No Rekamedis</label>
                    <input wire:model.lazy='no_rekamedis' type="text" class="form-control" readonly>
                </div>

                <div class="form-group">
                    <?php if(!$showDataPasien): ?>
                        <a href="#!" wire:click='openDetailPasien'>Lihat semua data</a>
                    <?php else: ?>
                        <a href="#!" wire:click='closeDetailPasien'>Tutup semua data</a>
                    <?php endif; ?>
                </div>
                
                <?php if($showDataPasien): ?>
                    <div class="form-group">
                        <label for="no_kk">No KK</label>
                        <input wire:model.lazy='no_kk' type="text" class="form-control" readonly>
                    </div>

                    <div class="form-group">
                        <label for="tanggal_lahir">Tanggal Lahir</label>
                        <input wire:model.lazy='tanggal_lahir' type="date" class="form-control" readonly>
                    </div>


                    <div class="form-group">
                        <label for="status_pasien">Status Pasien</label>
                        <input wire:model.lazy='status_pasien' type="text" class="form-control" readonly>
                    </div>

                    <div class="form-group">
                        <label for="no_jaminan">No Jaminan Kesehatan</label>
                        <input wire:model.lazy='no_jaminan' type="text" class="form-control" readonly>
                    </div>

                    <div class="form-group">
                        <label for="wilayah">Wilayah</label>
                        <input wire:model.lazy='wilayah' type="text" class="form-control" readonly>
                    </div>

                    <div class="form-group">
                        <label for="alamat">Alamat</label>
                        <textarea rows="3" wire:model.lazy='alamat' class="form-control" readonly></textarea>
                    </div>

                    <div class="form-group">
                        <label for="nama_penanggung_jawab">Nama Penanggung Jawab</label>
                        <input wire:model.lazy='nama_penanggung_jawab' type="text" class="form-control <?php $__errorArgs = ['nama_penanggung_jawaba'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        placeholder="Masukkan nama penanggung jawab" disabled>
                        <?php $__errorArgs = ['nama_penanggung_jawab'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>  

                    <div class="form-group">
                        <label for="hubungan">Hubungan</label>
                        <select wire:model.lazy='hubungan' class="form-control <?php $__errorArgs = ['hubungan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="hubungan" disabled>
                            <option selected>Pilih</option>
                            <option value="anak">Anak</option>
                            <option value="orang tua">Orang Tua</option>
                            <option value="suami">Suami</option>
                            <option value="istri">Istri</option>
                            <option value="kakak">Kakak</option>
                            <option value="adik">Adik</option>
                            <option value="kakek">Kakek</option>
                            <option value="nenek">Nenek</option>
                            <option value="tetangga">Tetangga</option>
                            <option value="saudara">Saudara</option>
                            <option value="paman">Paman</option>
                            <option value="bibi">Bibi</option>
                            <option value="om">Om</option>
                            <option value="tante">Tante</option>
                            <option value="orang lain">Orang Lain</option>
                        </select>
                        <?php $__errorArgs = ['hubungan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                <?php endif; ?>

           

            </div>
        </div>

       
        <div class="form-group" style="margin-top: 3% ;">
            <?php if($pendaftaranId): ?>
                <button class="btn btn-primary">Update</button>
                <button type="button" wire:click='closeFormCreatePendaftaran' class="btn btn-sm btn-primary" style="margin-left: 5px">X</button>
            <?php else: ?>
                <button class="btn btn-primary">Submit</button>
                <button type="button" wire:click='closeFormCreatePendaftaran' class="btn btn-sm btn-primary" style="margin-left: 5px">X</button>
            <?php endif; ?>
        </div>

    </form>
</div>

<script>
    $(document).ready(function() {
        $('#pasien').select2();

        $('#pasien').on('change', function() {
                window.livewire.find('<?php echo e($_instance->id); ?>').pasien = $(this).val();
         })
    });
</script><?php /**PATH /home/zamzam/Documents/Backups DEKSTOP/My Project/freelance/laravel-puskesmas/resources/views/livewire/admin/components/pasien.blade.php ENDPATH**/ ?>