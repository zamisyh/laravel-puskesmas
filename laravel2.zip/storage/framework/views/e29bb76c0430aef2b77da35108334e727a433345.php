<table border="1" cellpadding='5'>
    <thead>
        <tr>
            <th>No</th>
            <th>No Antrian</th>
            <th>No RM</th>
            <th>KIS/BPJS</th>
            <th>Nama Pasien</th>
            <th>Nama KK</th>
            <th colspan="2">Usia</th>
            <th>Tanggal Lahir</th>
            <th>Alamat</th>
            <th>DW</th>
            <th>LW</th>
            <th>Ket</th>
            
        </tr>
    </thead>
    <tbody>
        <tr>
            <td></td>
			<td></td>
			<td></td>
			<td></td>
			<td></td>
            <td></td>
			<td>L</td>
			<td>P</td>
            <td></td>
			<td></td>
			<td></td>
        </tr>
        <?php $__currentLoopData = $pasien; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($item->no_antrian); ?></td>
                <td><?php echo e($item->kode_paramedis); ?></td>
                <td><?php echo e($item->no_jaminan); ?></td>
                <td><?php echo e($item->nama_pasien); ?></td>
                <td><?php echo e($item->nama_kk); ?></td>
                <?php if($item->jenis_kelamin == 'L'): ?>
                    <td><?php echo e($item->usia); ?></td>
                    <td></td>
                <?php else: ?>
                    <td></td>
                    <td><?php echo e($item->usia); ?></td>
                <?php endif; ?>
                <td><?php echo e($item->tanggal_lahir); ?></td>
                <td><?php echo e($item->alamat); ?></td>
                <?php if($item->wilayah == 'Dalam Wilayah'): ?>
                    <td>&#10004;</td>
                    <td></td>
                <?php else: ?>
                    <td></td>
                    <td>&#10004;</td>
                <?php endif; ?>
                <td><?php echo e($item->keterangan); ?></td>
                    
               
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH /home/zamzam/Documents/Backups DEKSTOP/My Project/freelance/laravel-puskesmas/resources/views/livewire/admin/exports/pasien.blade.php ENDPATH**/ ?>