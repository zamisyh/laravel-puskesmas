<table class="table table-bordered table-striped table-hover">
    <thead>
        <tr>
            <th>No</th>
            <th>Kode</th>
            <th>Nama</th>    
            <th>Jenis</th>
            <th>Dosis</th>
            <th>Satuan</th>
            <th>Sediaan</th>
        </tr>   
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $obats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($item->kode_obat); ?></td>
                <td><?php echo e($item->nama_obat); ?></td>    
                <td><?php echo e($item->jenis_obat); ?></td>
                <td><?php echo e($item->dosis_aturan_obat); ?></td>
                <td><?php echo e($item->satuan); ?></td>
                <td><?php echo e($item->sediaan); ?></td>
            </tr>   
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <td colspan="8" class="text-center">Data not found</td>
        <?php endif; ?>
    </tbody>
</table><?php /**PATH /home/zamzam/Documents/Backups DEKSTOP/My Project/freelance/laravel-puskesmas/resources/views/livewire/admin/exports/obat.blade.php ENDPATH**/ ?>