<div>

    <?php $__env->startSection('title', 'Home Dashboard'); ?>

    <div id="app">
        <?php echo $__env->make('livewire.admin.components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div id="main" class='layout-navbar'>
            <?php echo $__env->make('livewire.admin.components.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div id="main-content">

                <div class="page-heading">
                    <div class="page-title">
                        <div class="row">
                            <div class="col-12 col-md-6 order-md-1 order-last">
                                <h3>Home Dashboard</h3>
                                <p class="text-subtitle text-muted">Hi, this is the main dashboard page</p>
                            </div>
                            <div class="col-12 col-md-6 order-md-2 order-first">
                                <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="<?php echo e(route('dash.home')); ?>">Dashboard</a></li>
                                        <li class="breadcrumb-item active" aria-current="page">Home
                                        </li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                    </div>
                    <section class="section">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Example Content</h4>
                            </div>
                            <div class="card-body">
                                Lorem ipsum dolor sit amet consectetur adipisicing elit. Consectetur quas omnis
                                laudantium tempore
                                exercitationem, expedita aspernatur sed officia asperiores unde tempora maxime odio
                                reprehenderit
                                distinctio incidunt! Vel aspernatur dicta consequatur!
                            </div>
                        </div>
                    </section>
                </div>

                <?php echo $__env->make('livewire.admin.components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            </div>
        </div>
    </div>

    <?php $__env->startSection('js'); ?>
        <script src="<?php echo e(asset('assets/vendors/perfect-scrollbar/perfect-scrollbar.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>

        <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
    <?php $__env->stopSection(); ?>
</div>
<?php /**PATH /home/zamzam/Documents/Backups DEKSTOP/My Project/freelance/laravel-puskesmas/resources/views/livewire/admin/home.blade.php ENDPATH**/ ?>