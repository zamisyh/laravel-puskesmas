<table class="table table-bordered table-striped table-hover">
    <thead>
            <tr>
                <th>No</th>
                <th>No Lab</th>
                <th>Nama</th>
                <th>Umur</th>
                <th>Alamat</th>
                <th>No. RM</th>
                <th>Jaminan Kesehatan</th>
                <th>Dokter Pengirim</th>
                <th>Asal Poli</th>
                <th>Tanggal</th>
            </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $labs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($item->no_rawat); ?></td>
                <td><?php echo e($item->pendaftaran->pasien->nama_pasien); ?></td>
                <td><?php echo e($item->pendaftaran->pasien->usia); ?></td>
                <td><?php echo e($item->pendaftaran->pasien->alamat); ?></td>
                <td><?php echo e($item->no_rekammedis); ?></td>
                <td><?php echo e($item->pendaftaran->status_pasien); ?></td>
                <td><?php echo e($item->pendaftaran->dokter->nama_dokter); ?></td>
                <td><?php echo e($item->pendaftaran->poli->nama_poli); ?></td>
                <td><?php echo e($item->created_at); ?></td>
            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

            <td colspan="10" class="text-center">Data not found</td>
        <?php endif; ?>
    </tbody>
    </table><?php /**PATH /home/zamzam/Documents/Backups DEKSTOP/My Project/freelance/laravel-puskesmas/resources/views/livewire/admin/exports/laboratorium.blade.php ENDPATH**/ ?>