<div>

    <?php $__env->startSection('title', 'Login Page'); ?>
    <?php $__env->startSection('css'); ?>
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/pages/auth.css')); ?>">
    <?php $__env->stopSection(); ?>


    <div id="auth">

        <div class="d-flex justify-content-center">
            <div class="col-lg-6 col-12 m-auto">
                <div id="auth-left">

                    <h1 class="auth-title">Sign in</h1>
                    <p class="auth-subtitle mb-5">Log in with your data that you entered during registration.</p>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div class="form-group position-relative has-icon-left mb-4">
                        <input wire:model='email' type="email" class="form-control form-control-xl <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Email">
                        <div class="form-control-icon">
                            <i class="bi bi-envelope"></i>
                        </div>
                    </div>
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div class="form-group position-relative has-icon-left mb-4">
                        <input wire:model='password' type="password" class="form-control form-control-xl <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Password">
                        <div class="form-control-icon">
                            <i class="bi bi-shield-lock"></i>
                        </div>
                    </div>
                    <div class="form-check form-check-lg d-flex align-items-end">
                        <input class="form-check-input me-2" type="checkbox" value="" id="flexCheckDefault">
                        <label class="form-check-label text-gray-600" for="flexCheckDefault">
                            Keep me logged in
                        </label>
                    </div>
                    <button wire:click.prevent='signinAction' wire:loading.remove class="btn btn-primary btn-block btn-lg shadow-lg mt-5">Sign in</button>
                    <button wire:loading wire:target='signinAction' type="button" disabled class="btn btn-primary btn-block btn-lg shadow-lg mt-5">
                        <span class="spinner-border" role="status"
                        aria-hidden="true"></span>
                    </button>

                    <?php if($redirect): ?>
                        <script>
                            setTimeout(function () {
                                window.location.href = "<?php echo e(route('dash.home')); ?>";
                            }, 3000);
                        </script>

                    <?php endif; ?>

                    <?php if(Auth::check()): ?>
                        <script>
                            window.location.href = "<?php echo e(route('dash.home')); ?>";
                        </script>
                    <?php endif; ?>


                </div>
            </div>
        </div>

    </div>
</div>
<?php /**PATH /home/zamzam/Desktop/My Project/freelance/laravel-puskesmas/resources/views/livewire/auth/login.blade.php ENDPATH**/ ?>