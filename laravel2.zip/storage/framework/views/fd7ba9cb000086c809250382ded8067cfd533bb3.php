<table border="1" cellpadding='5'>
    <thead>
        <tr>
            <th>No</th>
            <th>No Rawat</th>
            <th>No RM</th>
            <th>Tanggal Daftar</th>
            <th>Nama Pasien</th>
            <th>Nama KK</th>
            <th>Tanggal Lahir</th>
            <th colspan="2">Usia</th>
            <th>Nama Dokter</th>
            <th>Poli Tujuan</th>
            <th>Status Pasien</th>
            <th>No Jaminan Kesehatan</th>
            
        </tr>
    </thead>
    <tbody>
        <tr>
            <td></td>
			<td></td>
			<td></td>
			<td></td>
			<td></td>
            <td></td>
            <td></td>
            <td>L</td>
			<td>P</td>
			<td></td>
			<td></td>
        </tr>
        <?php $__currentLoopData = $pendaftaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($item->no_rawat); ?></td>
                <td><?php echo e($item->no_rekammedis); ?></td>
                <td><?php echo e($item->tanggal_daftar); ?></td>
                <td><?php echo e($item->pasien->nama_pasien); ?></td>
                <td><?php echo e($item->pasien->nama_kk); ?></td>
                <td><?php echo e($item->pasien->tanggal_lahir); ?></td>
                <?php if($item->pasien->jenis_kelamin == 'L'): ?>
                    <td><?php echo e($item->pasien->usia); ?></td>
                    <td></td>
                <?php else: ?>
                    <td></td>
                    <td><?php echo e($item->pasien->usia); ?></td>
                <?php endif; ?>
                <td><?php echo e($item->dokter->nama_dokter); ?></td>
                <td><?php echo e($item->poli->nama_poli); ?></td>
                <td><?php echo e($item->status_pasien); ?></td>
                <td><?php echo e($item->no_jaminan); ?></td>
                    
               
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH /home/zamzam/Documents/Backups DEKSTOP/My Project/freelance/laravel-puskesmas/resources/views/livewire/admin/exports/pendaftaran.blade.php ENDPATH**/ ?>