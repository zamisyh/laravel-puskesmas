<div class="card">
    <div class="card-header">
        <h4>Input Rujukan</h4>
    </div>
    <div class="card-body">
        <form wire:submit.prevent='saveRujukan'>
            <div class="form-group">
                <label for="nama_pasien">Nama Pasien</label>
                <input type="text" wire:model='nama_pasien' class="form-control <?php $__errorArgs = ['nama_pasien'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    is-invalid
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" readonly>
            </div>
            <div class="form-group">
                <label for="diagnosa">Diagnosa</label>
                <input type="hidden" wire:model='nama_diagnosa' class="form-control <?php $__errorArgs = ['nama_diagnosa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    is-invalid
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" readonly>
    
                <p><?php echo e($nama_diagnosa); ?></p>
            </div>
    
            <div class="form-group">
                <label for="nama_rumah_sakit">Nama Rumah Sakit</label>
                <input type="text" wire:model='nama_rumah_sakit' class="form-control <?php $__errorArgs = ['nama_rumah_sakit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    is-invalid
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
            </div>
    
            <div class="form-group">
                <label for="poli_rujukan_tujuan">Poli Tujuan</label>
                <input type="text" wire:model='poli_rujukan_tujuan' class="form-control <?php $__errorArgs = ['poli_rujukan_tujuan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    is-invalid
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
            </div>

            <button class="btn btn-success">Submit</button>
        </form>
    </div> 
</div><?php /**PATH /home/zamzam/Desktop/My Project/freelance/laravel-puskesmas/resources/views/livewire/admin/tindakan/components/i-rujukan.blade.php ENDPATH**/ ?>