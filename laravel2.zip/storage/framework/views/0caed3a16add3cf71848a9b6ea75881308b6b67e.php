<div>

    <?php $__env->startSection('title', 'Pendaftaran'); ?>

    <div id="app">
        <?php echo $__env->make('livewire.admin.components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div id="main" class='layout-navbar'>
            <?php echo $__env->make('livewire.admin.components.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div id="main-content">

                <div class="page-heading">
                    <div class="page-title">
                        <div class="row">
                            <div class="col-12 col-md-6 order-md-1 order-last">
                                <h3>Pendaftaran</h3>
                                <p class="text-subtitle text-muted">Hi, this is page for manajement data Pendaftaran</p>
                            </div>
                            <div class="col-12 col-md-6 order-md-2 order-first">
                                <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="<?php echo e(route('dash.home')); ?>">Dashboard</a></li>
                                        <li class="breadcrumb-item active" aria-current="page">Pendaftaran
                                        </li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                    </div>
                    <section class="section">
                        <div class="card">
                            <?php if($openFormCreate): ?>
                            
                            <div class="card-body">
                                <form
                                    <?php if($pendaftaranId): ?>
                                        wire:submit.prevent='updatePendaftaran(<?php echo e($pendaftaranId); ?>)'
                                    <?php else: ?>
                                        wire:submit.prevent='savePendaftaran'
                                    <?php endif; ?>
                                >
                                   
                                    <div class="row">
                                        <div class="col-lg-5">
                                            <h5>Data Pendaftaran</h5>

                                            <div class="form-group">
                                                <label for="no_rawat">No Rawat</label>
                                                <input wire:model.lazy='no_rawat' type="text" class="form-control" readonly>
                                            </div>

                                            <div class="form-group">
                                                <label for="dokter">Dokter Penanggung Jawab</label>
                                                <select wire:model.lazy='dokter' class="form-control <?php $__errorArgs = ['dokter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="dokter">
                                                    <option selected>Pilih</option>
                                                     <?php $__currentLoopData = $data_dokter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama_dokter); ?></option>
                                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <?php $__errorArgs = ['dokter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>

                                            <div class="form-group">
                                                <label for="poli">Poli Tujuan</label>
                                                <select wire:model.lazy='poli' class="form-control <?php $__errorArgs = ['poli'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="poli">
                                                    <option selected>Pilih</option>
                                                     <?php $__currentLoopData = $data_poli; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama_poli); ?></option>
                                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <?php $__errorArgs = ['poli'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div> 
                                        <div class="col-lg-7">
                                            <h5>Data Pasien</h5>
                                            
                                    
                                            <div class="form-group">
                                                <label for="pasien">Pasien</label>
                                                <select wire:model.lazy='pasien' class="form-control <?php $__errorArgs = ['pasien'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="pasien">
                                                    <option selected>Pilih</option>
                                                     <?php $__currentLoopData = $data_pasien; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama_pasien); ?></option>
                                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <?php $__errorArgs = ['pasien'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>

                                            <div class="form-group">
                                                <label for="no_rekamedis">No Rekamedis</label>
                                                <input wire:model.lazy='no_rekamedis' type="text" class="form-control" readonly>
                                            </div>

                                            <div class="form-group">
                                                <?php if(!$showDataPasien): ?>
                                                    <a href="#!" wire:click='openDetailPasien'>Lihat semua data</a>
                                                <?php else: ?>
                                                    <a href="#!" wire:click='closeDetailPasien'>Tutup semua data</a>
                                                <?php endif; ?>
                                            </div>
                                            
                                            <?php if($showDataPasien): ?>
                                                <div class="form-group">
                                                    <label for="no_kk">No KK</label>
                                                    <input wire:model.lazy='no_kk' type="text" class="form-control" readonly>
                                                </div>

                                                <div class="form-group">
                                                    <label for="tanggal_lahir">Tanggal Lahir</label>
                                                    <input wire:model.lazy='tanggal_lahir' type="date" class="form-control" readonly>
                                                </div>

                            
                                                <div class="form-group">
                                                    <label for="status_pasien">Status Pasien</label>
                                                    <input wire:model.lazy='status_pasien' type="text" class="form-control" readonly>
                                                </div>

                                                <div class="form-group">
                                                    <label for="no_jaminan">No Jaminan</label>
                                                    <input wire:model.lazy='no_jaminan' type="text" class="form-control" readonly>
                                                </div>

                                                <div class="form-group">
                                                    <label for="wilayah">Wilayah</label>
                                                    <input wire:model.lazy='wilayah' type="text" class="form-control" readonly>
                                                </div>

                                                <div class="form-group">
                                                    <label for="alamat">Alamat</label>
                                                    <textarea rows="3" wire:model.lazy='alamat' class="form-control" readonly></textarea>
                                                </div>
                                            <?php endif; ?>

                                            <div class="form-group">
                                                <label for="nama_penanggung_jawab">Nama Penanggung Jawab</label>
                                                <input wire:model.lazy='nama_penanggung_jawab' type="text" class="form-control <?php $__errorArgs = ['nama_penanggung_jawaba'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                placeholder="Masukkan nama penanggung jawab">
                                                <?php $__errorArgs = ['nama_penanggung_jawab'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>  

                                            <div class="form-group">
                                                <label for="hubungan">Hubungan</label>
                                                <select wire:model.lazy='hubungan' class="form-control <?php $__errorArgs = ['hubungan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="hubungan">
                                                    <option selected>Pilih</option>
                                                    <option value="anak">Anak</option>
                                                    <option value="orang tua">Orang Tua</option>
                                                    <option value="suami">Suami</option>
                                                    <option value="istri">Istri</option>
                                                    <option value="kakak">Kakak</option>
                                                    <option value="adik">Adik</option>
                                                    <option value="kakek">Kakek</option>
                                                    <option value="nenek">Nenek</option>
                                                    <option value="tetangga">Tetangga</option>
                                                    <option value="saudara">Saudara</option>
                                                    <option value="paman">Paman</option>
                                                    <option value="bibi">Bibi</option>
                                                    <option value="om">Om</option>
                                                    <option value="tante">Tante</option>
                                                    <option value="orang lain">Orang Lain</option>
                                                </select>
                                                <?php $__errorArgs = ['hubungan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>

                                            <div class="form-group">
                                                <label for="alamat_penanggung_jawab">Alamat Penanggung Jawab</label>
                                                <textarea rows="4" wire:model.lazy='alamat_penanggung_jawab' class="form-control <?php $__errorArgs = ['alamat_penanggung_jawab'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan alamat"></textarea>
                                              
                                                <?php $__errorArgs = ['alamat_penanggung_jawab'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>  
                                            
                                        </div>
                                    </div>

                                   
                                    <div class="form-group" style="margin-top: 3% ;">
                                        <?php if($pendaftaranId): ?>
                                            <button class="btn btn-primary">Update</button>
                                            <button type="button" wire:click='closeFormCreatePendaftaran' class="btn btn-sm btn-primary" style="margin-left: 5px">X</button>
                                        <?php else: ?>
                                            <button class="btn btn-primary">Submit</button>
                                            <button type="button" wire:click='closeFormCreatePendaftaran' class="btn btn-sm btn-primary" style="margin-left: 5px">X</button>
                                        <?php endif; ?>
                                    </div>

                                </form>
                            </div>

                            <?php else: ?>

                                <div class="card-header">
                                    <div class="d-flex justify-content-between">
                                        <h4>Data Pendaftaran</h4>
                                        <div>
                                            <button wire:click='openFormCreatePendaftaran' class="btn btn-sm btn-primary">Tambah Data</button>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-body">

                                    <div>
                                        <input type="text" wire:model='search' placeholder="Search by no, rekamedis, nama">
                                        <select wire:model='rows'>
                                            <option value="5" selected>5</option>
                                            <option value="10" selected>10</option>
                                            <option value="15" selected>15</option>
                                            <option value="20" selected>20</option>
                                        </select>

                                        <?php if(!$details): ?>
                                                <button wire:click='openDetails' class="btn btn-primary btn-sm">
                                                    <i class="bi bi-eye-slash-fill"></i>
                                                </button>

                                            <?php else: ?>
                                                <button wire:click='closeDetails' class="btn btn-primary btn-sm">
                                                    <i class="bi bi-eye-fill"></i>
                                                </button>
                                        <?php endif; ?>

                                    </div>

                                    <p></p>

                                    <div class="table-responsive">
                                        <table class="table table-bordered table-striped table-hover">
                                        <thead>
                                                <tr>
                                                    <th>No</th>
                                                    <th>No Rawat</th>
                                                    <th>No Rekamedis</th>
                                                    <th>Nama Pasien</th>
                                                    <th>Status</th>
                                                    <?php if($details): ?>
                                                        <th>Nama Dokter</th>
                                                        <th>Jenis Poli</th>
                                                    <?php endif; ?>
                                                    <th>Actions</th>
                                                </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__empty_1 = true; $__currentLoopData = $pendaftarans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <tr>
                                                    <td><?php echo e($pendaftarans->firstItem() + $key); ?></td>
                                                    <td><?php echo e($item->no_rawat); ?></td>
                                                    <td><?php echo e($item->no_rekammedis); ?></td>
                                                    <td><?php echo e($item->pasien->nama_pasien); ?></td>
                                                    <td><?php echo e($item->status_pasien); ?></td>
                                                    <?php if($details): ?>
                                                        <td><?php echo e($item->dokter->nama_dokter); ?></td>
                                                        <td><?php echo e($item->poli->nama_poli); ?></td>
                                                    <?php endif; ?>
                                                    <td class="d-flex">
                                                        <button wire:click="openFormUpdatePendaftaran(<?php echo e($item->id); ?>)" class="btn btn-primary btn-sm">
                                                            <i class="bi bi-pencil-square"></i>
                                                        </button>
                                                        <button wire:click.prevent='deletePendaftaran(<?php echo e($item->id); ?>)' style="margin-left: 5px" class="btn btn-danger btn-sm">
                                                            <i class="bi bi-trash-fill"></i>
                                                        </button>
                                                    </td>
                                                </tr>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                                <td colspan="10" class="text-center">Data not found</td>
                                            <?php endif; ?>
                                        </tbody>
                                        </table>
                                    </div>

                                    <div>
                                        <?php echo e($pendaftarans->links()); ?>

                                    </div>
                                </div>

                            <?php endif; ?>
                        </div>
                    </section>
                </div>

                <?php echo $__env->make('livewire.admin.components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            </div>
        </div>
    </div>

    <?php $__env->startSection('js'); ?>
        <script src="<?php echo e(asset('assets/vendors/perfect-scrollbar/perfect-scrollbar.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>

        <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
    <?php $__env->stopSection(); ?>
</div>
<?php /**PATH /home/zamzam/Desktop/My Project/freelance/laravel-puskesmas/resources/views/livewire/admin/pendaftaran.blade.php ENDPATH**/ ?>