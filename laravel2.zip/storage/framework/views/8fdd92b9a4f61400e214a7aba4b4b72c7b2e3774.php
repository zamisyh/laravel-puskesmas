<div>

    <?php $__env->startSection('css'); ?>
        <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/simple-datatables/style.css')); ?>">

        <style>
            .closed:hover{
                cursor: pointer;
                opacity: 5.0;
            }
        </style>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('title', 'Reports'); ?>

    <div id="app">
        <?php echo $__env->make('livewire.admin.components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div id="main" class='layout-navbar'>
            <?php echo $__env->make('livewire.admin.components.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div id="main-content">

                <div class="page-heading">
                    <div class="page-title">
                        <div class="row">
                            <div class="col-12 col-md-6 order-md-1 order-last">
                                <h3>Reports</h3>
                                <p class="text-subtitle text-muted">Hi, this is the main report page</p>
                            </div>
                            <div class="col-12 col-md-6 order-md-2 order-first">
                                <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="<?php echo e(route('dash.home')); ?>">Dashboard</a></li>
                                        <li class="breadcrumb-item active" aria-current="page">Report
                                        </li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                    </div>
                    <section class="section">
                        <div class="card">
                            <div class="card-header d-flex justify-content-between">
                                <h4 class="card-title">Data <?php echo e($title); ?></h4>
                                <div>
                                    <select wire:model='choice' class="form-select">
                                        <option value="dokter">Dokter</option>
                                        <option value="pasien">Pasien</option>
                                        <option value="pendaftaran">Pendaftaran</option>
                                        <option value="obat">Obat</option>
                                        <option value="lab">Laboratorium</option>
                                    </select>
                                </div>
                            </div>
                            <div class="card-body">
                               <?php if($choice == 'pasien'): ?>

                               <div class="d-flex justify-content-between">
                                    <div class="mt-3 mb-3">
                                        <input type="text" wire:model='search' placeholder="Search data <?php echo e(strtolower($title)); ?>">
                                        <select wire:model='rows'>
                                            <option value="5" selected>5</option>
                                            <option value="10" selected>10</option>
                                            <option value="15" selected>15</option>
                                            <option value="20" selected>20</option>
                                        </select>

                                        <?php if(!$details): ?>
                                                <button wire:click='openDetails' class="btn btn-primary btn-sm">
                                                    <i class="bi bi-eye-slash-fill"></i>
                                                </button>

                                            <?php else: ?>
                                                <button wire:click='closeDetails' class="btn btn-primary btn-sm">
                                                    <i class="bi bi-eye-fill"></i>
                                                </button>
                                        <?php endif; ?>
                                            
                                    </div>
                                    <div></div>
                               </div>

                               <div class="mb-4 mt-1 d-flex">
                                <?php if(!$filter): ?>
                                     <div>
                                        <button wire:click='openFormFilter' class="btn btn-success btn-sm">
                                            <i class="bi bi-filter-right"></i>
                                        </button>
                                     </div>
                                <?php else: ?>
                                     
                                    <div class="d-flex">
                                         <span style="margin-right:6px;" class="text-danger closed" wire:click='closeFormFilter'>
                                             <i class="bi bi-x-square"></i>
                                         </span>
                                         <select wire:model='resFilter'>
                                             <option value="" selected>Pilih</option>
                                             <option value="byDate">By Date</option>
                                             <option value="byAll">By All</option>
                                         </select>
                                    </div>
                                   
                                <?php endif; ?>

                                <div style="margin-left:5px;">
                                    <?php if($filter): ?>
                                        <?php if($resFilter == 'byAll'): ?>
                                        <button wire:click='pasienExportAll' class="btn btn-success btn-sm">Export</button>

                                        <?php elseif($resFilter == 'byDate'): ?>
                                            <input type="date" wire:model='from'> sampai <input type="date" wire:model='to'>
                                            <button wire:click='pasienExportByDate' class="btn btn-success btn-sm"><i class="bi bi-check2-square"></i></button>
                                        <?php endif; ?>

                                       
                                    <?php endif; ?>
                                </div>
                             </div>

                                <div class="table-responsive">
                                    <table class="table table-bordered table-striped table-hover">
                                    <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>No Rekamedis</th>
                                                <th>No Antrian</th>
                                                <th>Nama Pasien</th>
                                                <th>Nama KK</th>
                                                <th>Usia</th>
                                                <th>No KK</th>
                                                <?php if($details): ?>
                                                    <th>No KTP Pasien</th>
                                                    <th>Jaminan</th>
                                                    <th>No Jaminan</th>
                                                    <th>Jenis Kelamin</th>
                                                    <th>TTL</th>
                                                    <th>Alamat</th>
                                                    <th>Wilayah</th>
                                                <?php endif; ?>
                                                <th>Actions</th>
                                            </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td><?php echo e($data->firstItem() + $key); ?></td>
                                                <td><?php echo e($item->kode_paramedis); ?></td>
                                                <td><?php echo e($item->no_antrian); ?></td>
                                                <td><?php echo e($item->nama_pasien); ?></td>
                                                <td><?php echo e($item->nama_kk); ?></td>
                                                <td><?php echo e($item->usia); ?></td>
                                                <td><?php echo e($item->no_kk); ?></td>
                                                <?php if($details): ?>
                                                <td><?php echo e($item->no_ktp); ?></td>

                                                    <td><?php echo e($item->jaminan->nama_jaminan); ?></td>
                                                    <td><?php echo e($item->no_jaminan); ?></td>
                                                    <td><?php echo e($item->jenis_kelamin); ?></td>
                                                    <td>
                                                        <?php echo e(ucwords(strtolower($item->tempat_lahir))); ?>,
                                                        <?php echo e(Carbon\carbon::parse($item->tanggal_lahir)->format('d M Y')); ?> 
                                                    
                                                    </td>
                                                    <td><?php echo e($item->alamat); ?></td>
                                                    <td><?php echo e($item->wilayah); ?></td>
                                                <?php endif; ?>
                                                <td>
                                                  
                                                </td>
                                            </tr>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                        <td colspan="14" class="text-center">Data not found</td>
                                    <?php endif; ?>
                                </tbody>
                                </table>
                            </div>

                            <div class="mt-3 mb-3">
                                <?php echo e($data->links()); ?>

                            </div>

                               <?php elseif($choice == 'dokter'): ?>
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <input type="text" wire:model='search' placeholder="Search by nama">
                                        <select wire:model='rows'>
                                            <option value="5" selected>5</option>
                                            <option value="10" selected>10</option>
                                            <option value="15" selected>15</option>
                                            <option value="20" selected>20</option>
                                        </select>
                                       
                                        <?php if(!$details): ?>
                                                <button wire:click='openDetails' class="btn btn-primary btn-sm">
                                                    <i class="bi bi-eye-slash-fill"></i>
                                                </button>
    
                                            <?php else: ?>
                                                <button wire:click='closeDetails' class="btn btn-primary btn-sm">
                                                    <i class="bi bi-eye-fill"></i>
                                                </button>
                                        <?php endif; ?>
    
                                    </div>
                                    <div>
                                        <button class="btn btn-success btn-sm" wire:click='dokterExportAll'>Export</button>
                                    </div>
                                </div>

                                <p></p>

                                <div class="table-responsive">
                                    <table class="table table-bordered table-striped table-hover">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Nama</th>
                                            <th>Jenis Kelamin</th>    
                                            <th>Nomor Induk Dokter</th>
                                            <th>Poli</th>
                                            <?php if($details): ?>
                                                <th>TTL</th>
                                                <th>Alamat</th>
                                            <?php endif; ?>
                                            
                                        </tr>   
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td><?php echo e($data->firstItem() + $key); ?></td>
                                                <td><?php echo e($item->nama_dokter); ?></td>
                                                <td>
                                                    <?php if($item->jenis_kelamin == 'L'): ?>
                                                        <span class="badge bg-primary">L</span>

                                                    <?php else: ?>
                                                        <span class="badge bg-success">P</span>
                                                    <?php endif; ?>    
                                                </td>    
                                                <td><?php echo e($item->nid); ?></td>
                                                <td><?php echo e($item->poli->nama_poli); ?></td>
                                                <?php if($details): ?>
                                                    <td>
                                                        <?php echo e(ucwords(strtolower($item->tempat_lahir))); ?>,
                                                        <?php echo e(Carbon\carbon::parse($item->tanggal_lahir)->format('d M Y')); ?>

                                                    </td>
                                                    <td><?php echo e($item->alamat); ?></td>
                                                <?php endif; ?>
                                               
                                            </tr>   
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <td colspan="8" class="text-center">Data not found</td>
                                        <?php endif; ?>
                                    </tbody>
                                    </table>
                                </div>

                                <div>
                                    <?php echo e($data->links()); ?>

                                </div>

                                <?php elseif($choice == 'pendaftaran'): ?>

                                        <div class="d-flex justify-content-between">
                                            <div class="mt-3 mb-3">
                                                <input type="text" wire:model='search' placeholder="Search data <?php echo e(strtolower($title)); ?>">
                                                <select wire:model='rows'>
                                                    <option value="5" selected>5</option>
                                                    <option value="10" selected>10</option>
                                                    <option value="15" selected>15</option>
                                                    <option value="20" selected>20</option>
                                                </select>

                                                <?php if(!$details): ?>
                                                        <button wire:click='openDetails' class="btn btn-primary btn-sm">
                                                            <i class="bi bi-eye-slash-fill"></i>
                                                        </button>

                                                    <?php else: ?>
                                                        <button wire:click='closeDetails' class="btn btn-primary btn-sm">
                                                            <i class="bi bi-eye-fill"></i>
                                                        </button>
                                                <?php endif; ?>
                                                    
                                            </div>
                                            <div></div>
                                    </div>

                                    <div class="mb-4 mt-1 d-flex">
                                        <?php if(!$filter): ?>
                                            <div>
                                                <button wire:click='openFormFilter' class="btn btn-success btn-sm">
                                                    <i class="bi bi-filter-right"></i>
                                                </button>
                                            </div>
                                        <?php else: ?>
                                            
                                            <div class="d-flex">
                                                <span style="margin-right:6px;" class="text-danger closed" wire:click='closeFormFilter'>
                                                    <i class="bi bi-x-square"></i>
                                                </span>
                                                <select wire:model='resFilter'>
                                                    <option value="" selected>Pilih</option>
                                                    <option value="byDate">By Date</option>
                                                    <option value="byAll">By All</option>
                                                </select>
                                            </div>
                                        
                                        <?php endif; ?>

                                        <div style="margin-left:5px;">
                                            <?php if($filter): ?>
                                                <?php if($resFilter == 'byAll'): ?>
                                                <button class="btn btn-success btn-sm" wire:click='pendaftaranExportAll'>Export</button>

                                                <?php elseif($resFilter == 'byDate'): ?>
                                                    <input type="date" wire:model='from'> sampai <input type="date" wire:model='to'>
                                                    <button wire:click='pendaftaranExportByDate' class="btn btn-success btn-sm"><i class="bi bi-check2-square"></i></button>
                                                <?php endif; ?>

                                            
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    

                                    

                                    <p></p>

                                    <div class="table-responsive">
                                        <table class="table table-bordered table-striped table-hover">
                                        <thead>
                                                <tr>
                                                    <th>No</th>
                                                    <th>No Rawat</th>
                                                    <th>No Rekamedis</th>
                                                    <th>Nama Pasien</th>
                                                    <th>Status</th>
                                                    <?php if($details): ?>
                                                        <th>Nama Dokter</th>
                                                        <th>Jenis Poli</th>
                                                    <?php endif; ?>
                                                    <th>Actions</th>
                                                </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <tr>
                                                    <td><?php echo e($data->firstItem() + $key); ?></td>
                                                    <td><?php echo e($item->no_rawat); ?></td>
                                                    <td><?php echo e($item->no_rekammedis); ?></td>
                                                    <td><?php echo e($item->pasien->nama_pasien); ?></td>
                                                    <td><?php echo e($item->status_pasien); ?></td>
                                                    <?php if($details): ?>
                                                        <td><?php echo e($item->dokter->nama_dokter); ?></td>
                                                        <td><?php echo e($item->poli->nama_poli); ?></td>
                                                    <?php endif; ?>
                                                    <td>
                                                        
                                                    </td>
                                                </tr>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                                <td colspan="10" class="text-center">Data not found</td>
                                            <?php endif; ?>
                                        </tbody>
                                        </table>
                                    </div>

                                    <div>
                                        <?php echo e($data->links()); ?>

                                    </div>

                                    <?php elseif($choice == 'obat'): ?>


                                    <div class="d-flex justify-content-between">
                                        <div>
                                            <input type="text" wire:model='search' placeholder="Search by kode, nama">
                                            <select wire:model='rows'>
                                                <option value="5" selected>5</option>
                                                <option value="10" selected>10</option>
                                                <option value="15" selected>15</option>
                                                <option value="20" selected>20</option>
                                            </select>
                                        </div>
                                        
                                        <div>
                                            <button class="btn btn-success btn-sm" wire:click='obatExportAll'>Export</button>
                                        </div>
                                    </div>

                                    <p></p>

                                    <div class="table-responsive">
                                        <table class="table table-bordered table-striped table-hover">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Kode</th>
                                                <th>Nama</th>    
                                                <th>Jenis</th>
                                                <th>Dosis</th>
                                                <th>Satuan</th>
                                                <th>Sediaan</th>
                                            </tr>   
                                        </thead>
                                        <tbody>
                                            <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <tr>
                                                    <td><?php echo e($data->firstItem() + $key); ?></td>
                                                    <td><?php echo e($item->kode_obat); ?></td>
                                                    <td><?php echo e($item->nama_obat); ?></td>    
                                                    <td><?php echo e($item->jenis_obat); ?></td>
                                                    <td><?php echo e($item->dosis_aturan_obat); ?></td>
                                                    <td><?php echo e($item->satuan); ?></td>
                                                    <td><?php echo e($item->sediaan); ?></td>
                                                </tr>   
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <td colspan="8" class="text-center">Data not found</td>
                                            <?php endif; ?>
                                        </tbody>
                                        </table>
                                    </div>

                                    <div>
                                        <?php echo e($data->links()); ?>

                                    </div>
                                    

                                    <?php elseif($choice == 'lab'): ?>



                                    <div class="d-flex justify-content-between">
                                        <div>
                                            <input type="text" wire:model='search' placeholder="Search data..">
                                            <select wire:model='rows'>
                                                <option value="5">5</option>
                                                <option value="10">10</option>
                                                <option value="15">15</option>
                                                <option value="20">20</option>
                                            </select>
                                        </div>
                                        <div>
                                            <button class="btn btn-success btn-sm" wire:click='labsExportAll'>Export</button>
                                        </div>
                                    </div>
                                    <p></p>
                                    <div class="table-responsive">
                                        <table class="table table-bordered table-striped table-hover">
                                            <thead>
                                                <tr>
                                                    <th>No</th>
                                                    <th>No Rawat</th>
                                                    <th>No Rekamedis</th>
                                                    <th>Nama Pasien</th>
                                                    <th>Created At</th>
                                                    <th>Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <tr>
                                                        <td><?php echo e($data->firstItem() + $key); ?></td>
                                                        <td><?php echo e($item->no_rawat); ?></td>
                                                        <td><?php echo e($item->no_rekammedis); ?></td>
                                                        <td><?php echo e($item->pasien->nama_pasien); ?></td>
                                                        <td><?php echo e($item->created_at); ?></td>
                                                        <td>
                                                            <button wire:click='labsExportWithId(<?php echo e($item->id); ?>)' class="btn btn-primary btn-sm">
                                                                <i class="bi bi-file-earmark-spreadsheet-fill"></i>
                                                            </button>
                                                        </td>
                                                    </tr>

                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                        <td class="text-center" colspan="6">No Data Found</td>

                                                <?php endif; ?>
                                            </tbody>
                                        </table>

                                        <div class="form-group">
                                            <?php echo e($data->links()); ?>

                                        </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </section>
                </div>

                <?php echo $__env->make('livewire.admin.components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            </div>
        </div>
    </div>

    <?php $__env->startSection('js'); ?>
        <script src="<?php echo e(asset('assets/vendors/perfect-scrollbar/perfect-scrollbar.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>

        <script src="<?php echo e(asset('assets/vendors/simple-datatables/simple-datatables.js')); ?>"></script>
        <script>
            // Simple Datatable
            let table1 = document.querySelector('#table');
            let dataTable = new simpleDatatables.DataTable(table);
        </script>
    

        <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
    <?php $__env->stopSection(); ?>
</div>
<?php /**PATH /home/zamzam/Documents/Backups DEKSTOP/My Project/freelance/laravel-puskesmas/resources/views/livewire/admin/reports.blade.php ENDPATH**/ ?>