<div>

    <?php $__env->startSection('css'); ?>
        <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/select2/select2.min.css')); ?>">
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('title', 'Pendaftaran'); ?>

    <div id="app">
        <?php echo $__env->make('livewire.admin.components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div id="main" class='layout-navbar'>
            <?php echo $__env->make('livewire.admin.components.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div id="main-content">

                <div class="page-heading">
                    <div class="page-title">
                        <div class="row">
                            <div class="col-12 col-md-6 order-md-1 order-last">
                                <h3>Pendaftaran</h3>
                                <p class="text-subtitle text-muted">Hi, this is page for manajement data Pendaftaran</p>
                            </div>
                            <div class="col-12 col-md-6 order-md-2 order-first">
                                <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="<?php echo e(route('dash.home')); ?>">Dashboard</a></li>
                                        <li class="breadcrumb-item active" aria-current="page">Pendaftaran
                                        </li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                    </div>
                    <section class="section">
                        <div class="card">
                            <?php if($openFormCreate): ?>
                            
                            <?php echo $__env->make('livewire.admin.components.pasien', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                            <?php else: ?>

                                <div class="card-header">
                                    <div class="d-flex justify-content-between">
                                        <h4>Data Pendaftaran</h4>
                                        <div>
                                            <button wire:click='openFormCreatePendaftaran' class="btn btn-sm btn-primary">Tambah Data</button>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-body">

                                    <div>
                                        <input type="text" wire:model='search' placeholder="Search by no, rekamedis, nama">
                                        <select wire:model='rows'>
                                            <option value="5" selected>5</option>
                                            <option value="10" selected>10</option>
                                            <option value="15" selected>15</option>
                                            <option value="20" selected>20</option>
                                        </select>

                                        <?php if(!$details): ?>
                                                <button wire:click='openDetails' class="btn btn-primary btn-sm">
                                                    <i class="bi bi-eye-slash-fill"></i>
                                                </button>

                                            <?php else: ?>
                                                <button wire:click='closeDetails' class="btn btn-primary btn-sm">
                                                    <i class="bi bi-eye-fill"></i>
                                                </button>
                                        <?php endif; ?>

                                    </div>

                                    <p></p>

                                    <div class="table-responsive">
                                        <table class="table table-bordered table-striped table-hover">
                                        <thead>
                                                <tr>
                                                    <th>No</th>
                                                    <th>No Rawat</th>
                                                    <th>No Rekamedis</th>
                                                    <th>Nama Pasien</th>
                                                    <th>Status</th>
                                                    <?php if($details): ?>
                                                        <th>Nama Dokter</th>
                                                        <th>Jenis Poli</th>
                                                    <?php endif; ?>
                                                    <th>Actions</th>
                                                </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__empty_1 = true; $__currentLoopData = $pendaftarans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <tr>
                                                    <td><?php echo e($pendaftarans->firstItem() + $key); ?></td>
                                                    <td><?php echo e($item->no_rawat); ?></td>
                                                    <td><?php echo e($item->no_rekammedis); ?></td>
                                                    <td><?php echo e($item->pasien->nama_pasien); ?></td>
                                                    <td><?php echo e($item->status_pasien); ?></td>
                                                    <?php if($details): ?>
                                                        <td><?php echo e($item->dokter->nama_dokter); ?></td>
                                                        <td><?php echo e($item->poli->nama_poli); ?></td>
                                                    <?php endif; ?>
                                                    <td class="d-flex">
                                                        <button wire:click="openFormUpdatePendaftaran(<?php echo e($item->id); ?>)" class="btn btn-primary btn-sm">
                                                            <i class="bi bi-pencil-square"></i>
                                                        </button>
                                                        <button wire:click.prevent='deletePendaftaran(<?php echo e($item->id); ?>)' style="margin-left: 5px" class="btn btn-danger btn-sm">
                                                            <i class="bi bi-trash-fill"></i>
                                                        </button>
                                                    </td>
                                                </tr>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                                <td colspan="10" class="text-center">Data not found</td>
                                            <?php endif; ?>
                                        </tbody>
                                        </table>
                                    </div>

                                    <div>
                                        <?php echo e($pendaftarans->links()); ?>

                                    </div>
                                </div>

                            <?php endif; ?>
                        </div>
                    </section>
                </div>

                <?php echo $__env->make('livewire.admin.components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            </div>
        </div>
    </div>

    <?php $__env->startSection('js'); ?>

        <script src="<?php echo e(asset('assets/vendors/jquery/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/vendors/select2/select2.min.js')); ?>"></script>
    
        <script src="<?php echo e(asset('assets/vendors/perfect-scrollbar/perfect-scrollbar.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>

        <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>

        
    <?php $__env->stopSection(); ?>
</div>





<?php /**PATH /home/zamzam/Documents/Backups DEKSTOP/My Project/freelance/laravel-puskesmas/resources/views/livewire/admin/pendaftaran.blade.php ENDPATH**/ ?>