<div>


    <?php $__env->startSection('css'); ?>
        <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/select2/select2.min.css')); ?>">
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('title', 'Perbaikan Gizi'); ?>

    <div id="app">
        <?php echo $__env->make('livewire.admin.components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div id="main" class='layout-navbar'>
            <?php echo $__env->make('livewire.admin.components.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div id="main-content">

                <div class="page-heading">
                    <div class="page-title">
                        <div class="row">
                            <div class="col-12 col-md-6 order-md-1 order-last">
                                <h3>Perbaikan Gizi</h3>
                                <p class="text-subtitle text-muted">Hi, this is page for manajement data Perbaikan Gizi</p>
                            </div>
                            <div class="col-12 col-md-6 order-md-2 order-first">
                                <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="<?php echo e(route('dash.home')); ?>">Dashboard</a></li>
                                        <li class="breadcrumb-item active" aria-current="page">Tindakan
                                        </li>
                                        <li class="breadcrumb-item active" aria-current="page">Perbaikan Gizi
                                        </li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                    </div>
                    <section class="section">
                        <div class="card">
                            <?php if($openFormCreate): ?>
                                <div class="card-header">
                                    <div class="d-flex justify-content-between">
                                        <h4><?php echo e($perbaikanGiziId ? 'Update' : 'Create'); ?> Perbaikan Gizi</h4>
                                        <div>
                                            <button wire:click='closeFormCreatePerbaikanGizi' class="btn btn-sm btn-primary">X</button>
                                        </div>
                                    </div>
                                </div>

                                <div class="card-body">
                                   <?php echo $__env->make('livewire.admin.components.perbaikan-gizi', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>

                            <?php else: ?>

                                <div class="card-header">
                                    <div class="d-flex justify-content-between">
                                        <h4>Data Perbaikan Gizi</h4>
                                        <div>
                                            <button wire:click='openFormCreatePerbaikanGizi' class="btn btn-sm btn-primary">Tambah Data</button>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-body">

                                    <div>
                                        <input type="text" wire:model='search' placeholder="Search by kode, nama">
                                        <select wire:model='rows'>
                                            <option value="5" selected>5</option>
                                            <option value="10" selected>10</option>
                                            <option value="15" selected>15</option>
                                            <option value="20" selected>20</option>
                                        </select>

                                    
                                    </div>

                                    <p></p>

                                    <div class="table-responsive">
                                        <table class="table table-bordered table-striped table-hover">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Nama Pasien</th>
                                                <th>Terapi</th>   
                                                <th>Tanggal Terapi</th> 
                                                <th>Hasil</th>
                                                <th>Actions</th>
                                            </tr>   
                                        </thead>
                                        <tbody>
                                            <?php $__empty_1 = true; $__currentLoopData = $perbaikan_gizis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <tr>
                                                    <td><?php echo e($perbaikan_gizis->firstItem() + $key); ?></td>
                                                    <td><?php echo e($item->pasien->nama_pasien); ?></td>
                                                    <td><?php echo e($item->terapi); ?></td>  
                                                    <td><?php echo e(Carbon\carbon::parse($item->tanggal)->format('d M Y')); ?></td>  
                                                    <td><?php echo e($item->hasil); ?></td>
                                                    
                                                    <td class="d-flex">
                                                        <button wire:click="openFormUpdatePerbaikanGizi(<?php echo e($item->id); ?>)" class="btn btn-primary btn-sm">
                                                            <i class="bi bi-pencil-square"></i>
                                                        </button>
                                                        <button wire:click.prevent='deletePerbaikanGizi(<?php echo e($item->id); ?>)' style="margin-left: 5px" class="btn btn-danger btn-sm">
                                                            <i class="bi bi-trash-fill"></i>
                                                        </button>
                                                    </td>
                                                </tr>   
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <td colspan="8" class="text-center">Data not found</td>
                                            <?php endif; ?>
                                        </tbody>
                                        </table>
                                    </div>

                                    <div>
                                        <?php echo e($perbaikan_gizis->links()); ?>

                                    </div>
                                </div>

                            <?php endif; ?>
                        </div>
                    </section>
                </div>

                <?php echo $__env->make('livewire.admin.components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            </div>
        </div>
    </div>

    <?php $__env->startSection('js'); ?>

        <script src="<?php echo e(asset('assets/vendors/jquery/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/vendors/select2/select2.min.js')); ?>"></script>


        <script src="<?php echo e(asset('assets/vendors/perfect-scrollbar/perfect-scrollbar.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>

        <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
    <?php $__env->stopSection(); ?>
</div>
<?php /**PATH /home/zamzam/Documents/Backups DEKSTOP/My Project/freelance/laravel-puskesmas/resources/views/livewire/admin/tindakan/perbaikan-gizi.blade.php ENDPATH**/ ?>